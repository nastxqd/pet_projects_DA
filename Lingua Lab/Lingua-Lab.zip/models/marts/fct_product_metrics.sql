select
  date(occurred_at) as metric_date,
  event_name,
  count(*) as events,
  count(distinct user_id) as unique_users,
  round(avg(response_latency_ms), 0) as avg_latency_ms,
  round(avg(token_cost), 4) as avg_token_cost,
  round(avg(task_success) * 100, 1) as task_success_rate
from {{ ref('stg_events') }}
group by 1, 2
