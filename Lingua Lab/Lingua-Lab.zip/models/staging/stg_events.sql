select
  id as event_id,
  user_id,
  event_name,
  datetime(occurred_at) as occurred_at,
  json_extract(properties_json, '$.model_name') as model_name,
  cast(json_extract(properties_json, '$.response_latency_ms') as integer) as response_latency_ms,
  cast(json_extract(properties_json, '$.token_cost') as real) as token_cost,
  cast(json_extract(properties_json, '$.task_success') as integer) as task_success,
  cast(json_extract(properties_json, '$.retry_count') as integer) as retry_count
from events
